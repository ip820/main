/********************************************************
 * Project:			Automated AT
 * Last updated:	17 Jaunary 2011
 * Developer:		Supannee Tanathong
 ********************************************************/

#include "Global.h"

double deg2rad(double degrees)
{
	return degrees * DEG_TO_RAD;
}

double rad2deg(double radians)
{
	return radians * RAD_TO_DEG;
}
